﻿//WILL BE USED TO GIVE CARDS THE FUNCIONALITY TO BE DRAGGED

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

//beginDragHandler and endDragHandler willnot work without dragHandler
public class Draggable : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    //x and y cooridnates of the mouse
    float x, y;

    public Transform parentReturn = null; //when cards cant go anywhere, whill return to this parent

    public void Update()
    {
        //sets the mouse positions
        x = Input.mousePosition.x;
        y = Input.mousePosition.y;
    }

    //WHEN THE DRAG BEGINS
    public void OnBeginDrag(PointerEventData eventData)
    {
        parentReturn = this.transform.parent; //gets original parent panel 
        this.transform.SetParent(this.transform.parent.parent);

        GetComponent<CanvasGroup>().blocksRaycasts = false;
    }

    //EVENTS OCCURING DURING THE DRAG
    public void OnDrag(PointerEventData eventData)
    {
        //sets the current position of the card based on the mouse position
        this.transform.position = Camera.main.ScreenToWorldPoint(new Vector3(x, y, 1.0f));
    }

    //EVENT HAPPENING AFTER THE DRAG
    public void OnEndDrag(PointerEventData eventData)
    {
        this.transform.SetParent(parentReturn);
        GetComponent<CanvasGroup>().blocksRaycasts = true;
    }
}
