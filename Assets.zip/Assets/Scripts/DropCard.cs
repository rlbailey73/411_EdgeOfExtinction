﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

//WILL BE USED TO DETERMINE WHERE TO DROP CARDS AND IF THEY ARE ABLE TO DROP THEM
public class DropCard : MonoBehaviour, IDropHandler, IPointerEnterHandler, IPointerExitHandler
{
    //determines where the drop occurs
    public void OnDrop(PointerEventData eventData)
    {
        Draggable d = eventData.pointerDrag.GetComponent<Draggable>();
        if(d != null)
        {
            d.parentReturn = this.transform;
        }
    }

    //whenthe pointer enters the drop zone
    public void OnPointerEnter(PointerEventData eventData)
    {
        
    }

    //when the pointer exits the drop zone
    public void OnPointerExit(PointerEventData eventData)
    {

    }
}
